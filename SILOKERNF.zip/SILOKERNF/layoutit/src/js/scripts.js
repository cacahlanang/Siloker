// Empty JS for your own code to be here
function login(){
//	alert("Anda Berhasil Login")
	let user = document.getElementById("recipient-name");
	let pass = document.getElementById("message-text");
	
	console.log("recipient-name :" + user.value);
	console.log("message-text :" + pass.value);
	if(user.value=="caca" && pass.value=="1234"){
		alert("Selamat Anda Berhasil Login Sebagai Admin");
		window.location = "Halaman Admin.html";
		return false;
	}
	else if(user.value=="admin" && pass.value=="12345"){
		alert("Selamat Anda Berhasil Login Sebagai Admin");
		window.location = " Halaman Admin.html";
		return false;
	}
	else{
		alert("Username dan Password anda salah !!!");
	}
}
// Empty JS for your own code to be here
function login(){
	//	alert("Anda Berhasil Login")
		let user = document.getElementById("recipient-name");
		let pass = document.getElementById("message-text");
		
		console.log("recipient-name :" + user.value);
		console.log("message-text :" + pass.value);
		if(user.value=="caca" && pass.value=="1234"){
			alert("Selamat Anda Berhasil Login Sebagai Admin");
			window.location = "Halaman Admin.html";
			return false;
		}
		else if(user.value=="admin" && pass.value=="12345"){
			alert("Selamat Anda Berhasil Login Sebagai Admin");
			window.location = " Halaman Admin.html";
			return false;
		}
		else{
			alert("Username dan Password anda salah !!!");
		}
	}